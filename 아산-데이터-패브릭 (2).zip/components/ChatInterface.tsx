// This component is deprecated in the Medical Data Fabric Platform.
export const ChatInterface = () => <div />;
